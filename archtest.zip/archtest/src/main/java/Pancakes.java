import com.google.appengine.api.taskqueue.DeferredTask;

public class Pancakes implements DeferredTask {
  @Override
  public void run() {
    System.out.println("Run Forest!");
    throw new RuntimeException("dsfdsfsdfsdfdsf");
  }
}
