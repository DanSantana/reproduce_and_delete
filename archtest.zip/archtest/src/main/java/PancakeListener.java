import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.google.appengine.api.taskqueue.DeferredTask;

public class PancakeListener implements ServletContextListener {

  private DeferredTask task = new Pancakes(); //If you comment this line, deployment will work.

  @Override
  public void contextInitialized(final ServletContextEvent servletContextEvent) {

  }

  @Override
  public void contextDestroyed(final ServletContextEvent servletContextEvent) {

  }
}
